#include "Equations.h"
//this function rewrites a string by copying a string unto it.
void my_str_n_cat(char *destination, char *source)
{
	int string_length = 1, index = 1;

	printf("Enter String Length: ");
	scanf("%d", &string_length);

	for (index = 0; index < string_length; index++)
	{
		if (source[index] == '\0')
		{
			break;
		}
		destination[index] = source[index];//copy character
	}

	destination[index] = '\0';
}
//this function sorts 5 words from a list into alphabetical order
void bubble_sort(char list[][10], int num_strings)
{
	int c = 1, u = num_strings, i = 0, z = 0;
	char temp[20] = { '\0' };

	if (num_strings <= 1)
	{
		return;
	}

	for (c = 0; c < u; c++)
	{
		for (i = 1; i < u; i++)
		{
			if (strcmp(list[i - 1], list[i]) > 0) //compare first letter of each word
			{
				for (z = 0; list[i - 1][z] != '\0'; z++)
				{
					temp[z] = list[i][z]; //store the word into temp
				}
				temp[z] = '\0';//tach on the null character
				for (z = 0; list[i - 1][z] != '\0'; z++)
				{
					list[i][z] = list[i - 1][z]; //replace the original word with the second word
				}
				list[i][z] = '\0';//amend on the null

				for (z = 0; temp[z] != '\0'; z++)
				{
					list[i - 1][z] = temp[z]; //replace the second word with temp, the stored original word
				}
				list[i - 1][z] = '\0';//amend on the null
			}

		}
	}

}
//this function prints the 5 words from main
void print_strings(char list[][10], int num_strings)
{
	int row_index = 0;

	while (row_index < num_strings)
	{
		printf("list[%d]: ", row_index); //prints the number of the word
		printf("%s\n", list[row_index]); //prints the word
		row_index++;
	}
}
//this function adds the sum of prime numbers from 2 to a specified n
int sum_primes(unsigned int number)
{
	int sum = 0, prime_or_nah = 0;

	prime_or_nah = is_prime(number); //determines if prime number

	if (number == 2) //stop recursing at 2
	{
		sum = 2;
	}
	else if (prime_or_nah == 1) //prime found
	{
		sum = sum_primes(number - 1) + number; //add current number to prime sum
	}
	else //not prime
	{
		sum = sum_primes(number - 1); //continue to check the next number
	}

	return sum; //return sum of prime
}
//this function finds prime numbers, retruning 1 if prime
int is_prime(unsigned int number)
{
	int prime_or_nah = 0, i = 0;

	for (i = 2; i < number; i++) 
	{
		if ((number % i == 0) && (number != i))//if number is divisible only by itself and is not 2, it is a prime
		{
			return 0;
		}
		else
		{
			prime_or_nah = 1;
		}
	}
	return prime_or_nah;
}
//this function finds the smallest sum of sequences in an array. 
//as one would think, negative numbers are always chosen first in the algorithm to be summed.
int smallest_sum_sequence(int arr[], int size)
{
	int index = 0, min = 0, sum = 0;

	min = arr[0];//set minimum to the 0th element
	sum = arr[0]; //set sum to 0th element

	for (index = 1; index < size; index++)
	{
		if (sum > 0)
		{
			sum = arr[index]; //if sum is greater than than 0, set to the next index
		}
		else
		{
			sum = sum + arr[index]; // if sum is smaller than last index, add the numbers
		}

		if (sum <= min)
		{
			min = sum; //reset min to the sum
		}
	}

	return min; //return the minimum
}