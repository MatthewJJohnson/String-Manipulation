#include "Equations.h"

int main(void)
{
	char string1[20] = "Ronald";
	char string2[20] = "McDonald";
	int sum_prime = 0;
	int user_n = 0;
	int numbers[10] = { 8, 2, 1, 3, 9, -2, -9, 6, -2, 13 };
	int smallest_sum = 0;

	char strings[10][10] = { "words", "cheat", "zoink", "coals", "angle" };

	my_str_n_cat(string1, string2);
	printf("New String 1: %s\n", string1); //display string
	system("pause");
	system("cls");

	print_strings(strings, 5); //prints the 5 strings
	system("pause");
	bubble_sort(strings, 5); // sorts the strings
	print_strings(strings, 5); //prints the 5 strings
	system("pause");
	system("cls");
	
	printf("Sum all primes between 2 and:(enter a number) ");
	scanf("%d", &user_n); //find number to start checking primes at
	sum_prime = sum_primes(user_n);
	printf("Sum of the Primes = %d\n", sum_prime); //display sum
	system("pause");
	system("cls");

	
	smallest_sum = smallest_sum_sequence(numbers, 10);
	printf("Smallest sequence sum: %d\n", smallest_sum); //display smallest sum
	system("pause");
	system("cls");

	return 0;
}