#ifndef EQUATIONS_H
#define EQUATIONS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void my_str_n_cat(char *destination, char *source);
void bubble_sort(char arr[][10], int num_str);
void print_strings(char arr[][10], int num_str);
int sum_primes(unsigned int number);
int is_prime(unsigned int number);
int smallest_sum_sequence(int arr[], int size);

#endif